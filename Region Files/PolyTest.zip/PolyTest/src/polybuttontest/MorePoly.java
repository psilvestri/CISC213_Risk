/**
 * @author malickav
 *
 */
	
	package polybuttontest;

	import javafx.application.Application;
	import javafx.stage.Stage;
	import javafx.scene.Scene;
	import javafx.scene.layout.Pane;
	import javafx.scene.paint.Color;
	import javafx.scene.shape.Line;
	import javafx.scene.Group; 
	import javafx.scene.shape.Polygon; 
	import javafx.scene.Cursor;
	import javafx.scene.input.MouseEvent; 
	import javafx.event.EventHandler;

	public class MorePoly extends Application {

		@Override
		public void start(Stage stage) {
			//Creating a Polygon 
		    Polygon territoryA = new Polygon();  
		    Polygon territoryB = new Polygon();  
	            Polygon territoryC = new Polygon();
	            Polygon territoryD = new Polygon();
			
		    
		      //Adding coordinates to the polygon 
		    territoryA.getPoints().addAll(new Double[]{ 
		    		  40.0,30.0,
	                          160.0,20.0,
	                          200.0,100.0,
	                          100.0,140.0,
	                          40.0,100.0
	                          
		      }); 
		    
		    //Adding coordinates to the polygon 
		    territoryB.getPoints().addAll(new Double[]{ 
	                          160.0,20.0,
	                          360.0,60.0,
	                          400.0,130.0,
	                          330.0,150.0,
	                          250.0,200.0,
	                          260.0,120.0,
	                          200.0,100.0,


		      }); 
	            
	            territoryC.getPoints().addAll(new Double[]{ 
	                          50.0,190.0,
	                          100.0,140.0,
	                          200.0,100.0,
	                          260.0,120.0,
	                          250.0,200.0,
	                          180.0,260.0
	                          
		      }); 
	                    
	            territoryD.getPoints().addAll(new Double[]{ 
	                          400.0,130.0,
	                          330.0,150.0,
	                          250.0,200.0,
	                          180.0,260.0,
	                          390.0,280.0
		      }); 
	            
	            
		    
		    territoryA.setFill(Color.RED);
		    territoryB.setFill(Color.YELLOWGREEN);
	            territoryC.setFill(Color.AQUAMARINE);
	            territoryD.setFill(Color.DARKGREEN);
		    
		      //Creating the mouse event handler 
		      EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() { 
		         @Override 
		         public void handle(MouseEvent e) { 
		                if (e.getEventType() == MouseEvent.MOUSE_PRESSED) {
		                	
		                	System.out.println("Mouse Pressed");
		                } 
		                else if(e.getEventType() == MouseEvent.MOUSE_CLICKED) {
		                	System.out.println(e.getSource().toString());
		                	System.out.println("Mouse CLICKED");
		                	
		                }
		                else
		                {
		                	System.out.println("Mouse Not Pressed");
		                	System.out.println(e.toString());
		                	System.out.println(e.getEventType());
		                }
		         } 
		      };  
		    
		      //Registering the event filter 
		      territoryA.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);  
		      territoryB.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);  
	              territoryC.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
	              territoryD.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
		        
		      //Creating a Group object  
		      Group root = new Group(territoryC, territoryD, territoryB, territoryA); 
		         
		      //Creating a scene object 
		      Scene scene = new Scene(root, 600, 300);  
		      
		      //Setting title to the Stage 
		      stage.setTitle("Drawing a Polygon"); 
		         
		      //Adding scene to the stage 
		      stage.setScene(scene); 
		      
		      //Displaying the contents of the stage 
		      stage.show(); 

		    
		    
		}  // end main

		public static void main(String[] args) {
			launch(args);
		}
	}



