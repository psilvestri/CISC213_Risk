package riskTest;

public interface TerritoryFinals {

	// all of the points of each polygon is stored here because they wont change
	// throughout the program
	final Double[][] points = {
			// x //y //x //y //x //y //x //y
			{ 50.00, 50.00, 50.00, 150.00, 150.00, 150.00, 150.00, 50.00 },
			{ 150.00, 50.00, 150.00, 150.00, 250.00, 150.00, 250.00, 50.00 },
			{ 50.00, 150.00, 50.00, 250.00, 150.00, 250.00, 150.00, 150.00 },
			{ 150.00, 150.00, 150.00, 250.00, 250.00, 250.00, 250.00, 150.00 },
			{ 250.00, 50.00, 250.00, 150.00, 350.00, 150.00, 350.00, 50.00 } };

	// final boolean[][] adjacent = {

}
